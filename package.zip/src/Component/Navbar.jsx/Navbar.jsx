import React from 'react'
import "./Navbar.css";
export const Navbar = () => {
    return (
        <div className="navbar">
            <h1 className='m-0 p-0'>Logo</h1>
            <h1 className='m-0 p-0'>User details</h1>
        </div>
    )
}
