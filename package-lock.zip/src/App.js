import React from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Sidebar from './Sidebar/Sidebar';
import Register from './Pages/Register/Register';
import Login from './Pages/Login/Login';
function App() {
  return (
    <>
      <React.Fragment>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />}></Route>
            <Route path="/" element={<Register />}></Route>
            <Route path="/sidebar" element={<Sidebar />}></Route>
          </Routes>
          {/* <Register /> */}
          {/* <Sidebar /> */}
        </BrowserRouter>
      </React.Fragment>
    </>
  );
}

export default App;

{/* <Routes>
          <Route path='/' element={<Dashboard />}></Route>
        </Routes> */}