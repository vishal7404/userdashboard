import React from "react";
const Test = () => {
    return (
        <>
            <h1 style={{ color: "Green" }}> Working</h1>
        </>
    )
}
export default Test;