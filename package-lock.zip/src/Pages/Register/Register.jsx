import React, { useEffect } from 'react'
import "./Register.css"
import { Container, Row, Col } from "react-bootstrap"
import { json, Link } from 'react-router-dom';
import User3 from "./../../Images/user3.jpg"
import { AiFillEye } from "react-icons/ai"
import { AiFillEyeInvisible } from "react-icons/ai"
import { useState } from 'react';
import axios from 'axios';
const Register = () => {
    const [passwordVisiblity, setPasswordVisiblity] = useState("password");
    const [confirmPasswordVisiblity, setConfirmPasswordVisiblity] = useState("password");
    const [name, setName] = useState("vishal");
    const [email, setEmail] = useState("asbc@gmail.com");
    const [phone, setPhone] = useState(9874656321);
    const [sponsor_Id, setSponsor_Id] = useState("IND5108");
    const [password, setPassword] = useState("123456");
    const [user_Id, setUser_Id] = useState("1213");
    const [data, setDate] = useState([]);
    const ChangeVisiblity = (str) => {
        if (str === "password") {
            if (passwordVisiblity === "password") {
                setPasswordVisiblity("text")
            } else {
                setPasswordVisiblity("password")
            }
        } else {
            if (confirmPasswordVisiblity === "password") {
                setConfirmPasswordVisiblity("text")
            } else {
                setConfirmPasswordVisiblity("password")
            }
        }
    }
    const SubmitForm = async () => {
        console.log("working")
        try {
            console.log("try working")
            let items = { name, email, phone, sponsor_Id, user_Id, password }
            const result = await fetch('http://192.168.1.12:3000/register', {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
                body: JSON.stringify(items)
            })
            const datamain = await result.json();
            console.log(datamain);
            setDate(datamain);
        }
        catch (err) {
            console.log(err);
        }

    }

    return (
        <React.Fragment>
            <Row>
                <Col md="6" className="loginLeft">
                    <div className="loginContent">
                        <h5>Nice to see you</h5>
                        <h1>Welcome</h1>
                        <hr></hr>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem voluptatum officiis quo quasi repudiandae aut fugit necessitatibus, est saepe quas.</p>
                    </div>
                </Col>
                <Col md="6" className="loginCol">
                    <div className="loginFormDiv">
                        <img src={User3}></img>
                        <h1>Register Account</h1>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorem accusamus ea magni iste reprehenderit nobis!</p>
                        <div className="loginForm">
                            <input id="sponsor_id" type="text" placeholder='Sponsor ID' />
                            <input id="username" type="text" placeholder='Username' />
                            <input id="name" type="text" placeholder='Name' />
                            <input id="phone" type="text" placeholder='Phone' />
                            <div className="passwordDiv">
                                <input id="password" type={passwordVisiblity} placeholder='Password' />
                                <i onClick={() => ChangeVisiblity("password")} > {passwordVisiblity === "password" ? <AiFillEye /> : <AiFillEyeInvisible />} </i>
                            </div>
                            <div className="passwordDiv">
                                <input id="confirm_password" type={confirmPasswordVisiblity} placeholder='Confirm Password' />
                                <i onClick={() => ChangeVisiblity("confirmPassword")} > {confirmPasswordVisiblity === "password" ? <AiFillEye /> : <AiFillEyeInvisible />} </i>
                            </div>
                            <button className="btnLogin" onClick={() => SubmitForm()}>Sign up</button>
                        </div>
                        <div className="loginLinkDiv">
                            <p>Already have account?</p>
                            <Link to="/login" className="loginLink">Login</Link>
                        </div>
                    </div>
                </Col>
            </Row>
        </React.Fragment>
    )
}

export default Register