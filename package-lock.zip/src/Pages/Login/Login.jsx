import React from 'react'
import "./Login.css"
import { Container, Row, Col } from "react-bootstrap"
import { Link } from 'react-router-dom';
import { AiFillEye } from "react-icons/ai"
import { AiFillEyeInvisible } from "react-icons/ai"
import { useState } from 'react';
import User3 from "./../../Images/user3.jpg"
const Login = () => {

    const [passwordVisiblity, setPasswordVisiblity] = useState("password");
    const ChangeVisiblity = () => {
        if (passwordVisiblity === "password") {
            setPasswordVisiblity("text")
        } else {
            setPasswordVisiblity("password")
        }
    }
    return (
        <React.Fragment>
            <Row>
                <Col md="6" className="loginLeft">
                    <div className="loginContent">
                        <h5>Nice to see you again</h5>
                        <h1>Welcome Back</h1>
                        <hr></hr>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem voluptatum officiis quo quasi repudiandae aut fugit necessitatibus, est saepe quas.</p>
                    </div>
                </Col>
                <Col md="6" className="loginCol">
                    <div className="loginFormDiv">
                        <img src={User3}></img>
                        <h1>Login Account</h1>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorem accusamus ea magni iste reprehenderit nobis!</p>
                        <div className="loginForm">
                            <input type="text" placeholder='Username' />
                            <div className="passwordDiv">
                                <input type={passwordVisiblity} placeholder='Password' />
                                <i onClick={ChangeVisiblity} > {passwordVisiblity === "password" ? <AiFillEye /> : <AiFillEyeInvisible />} </i>
                            </div>
                            <Link className="btnLogin" to="/sidebar">Login</Link>
                        </div>
                        <div className="loginLinkDiv">
                            <p>Don't have account?</p>
                            <Link to='/' className="loginLink">Register</Link>
                        </div>
                    </div>
                </Col>
            </Row>
        </React.Fragment>
    )
}

export default Login