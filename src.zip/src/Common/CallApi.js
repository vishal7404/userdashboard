import React from 'react'
const CallApi = async (token, url) => {
    console.log("url", url);
    console.log("tokeccccn", token);
    // try {
    //     const token = props.token;
    //     const response = await fetch(props.url, {
    //         method: 'POST',
    //         headers: {
    //             "Content-Type": "application/json",
    //             "Accept": "application/json",
    //             "Authorization": token,
    //         }
    //     })
    //     var data = await response.json();
    //     console.log("mydata", data);
    // }
    // catch (e) { console.log(e) }

}
export { CallApi }